from setuptools import setup

setup(name='gaussian_binom',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['gaussian_binom'],
      author='Jason Ndirangu',
      author_email='bgathendu@live.com',
      zip_safe=False)
